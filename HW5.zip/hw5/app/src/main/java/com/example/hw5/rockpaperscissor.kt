package com.example.hw5

import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.util.Random



class rockpaperscissor : AppCompatActivity() {
    private lateinit var text_Result: TextView
    private lateinit var imbtn_Scissors: ImageButton
    private lateinit var imbtn_Stone: ImageButton
    private lateinit var imbtn_Paper: ImageButton
    private lateinit var image_Com: ImageView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_rockpaperscissor)
       // ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
      //      val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
       //     v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
    //        insets
     //   }

        image_Com = findViewById(R.id.image_Com)
        text_Result = findViewById(R.id.txtResult)
        imbtn_Scissors = findViewById(R.id.imbtn_Scissors)
        imbtn_Stone = findViewById(R.id.imbtn_Stone)
        imbtn_Paper = findViewById(R.id.imbtn_Paper)
        val btnBacktoFirst = findViewById<Button>(R.id.btnBacktoFirst)



        btnBacktoFirst.setOnClickListener{
            finish()
        }

        imbtn_Scissors.setOnClickListener {
            playGame(Choice.SCISSORS)
        }

        imbtn_Stone.setOnClickListener {
            playGame(Choice.ROCK)
        }

        imbtn_Paper.setOnClickListener {
            playGame(Choice.PAPER)
        }
    }


    var lastTime: Long = 0
    override fun finish() {
        val currentTime = System.currentTimeMillis()
        if (currentTime- lastTime > 3 * 1000) {
            lastTime = currentTime
            Toast.makeText(this,  "再按一下離開", Toast.LENGTH_SHORT).show()
        } else {
        }
        super.finish()
    }

    fun getChoiceString(choice: Choice): Int {
        return when (choice) {
            Choice.SCISSORS -> R.string.scissors
            Choice.ROCK -> R.string.rock
            Choice.PAPER -> R.string.paper
        }
    }

    enum class Choice {
        SCISSORS, ROCK, PAPER
    }

    fun playGame(playerChoice: Choice) {
        val choices = Choice.values()
        val computerChoice = choices[Random().nextInt(choices.size)]
        image_Com.setImageResource(getChoiceDrawable(computerChoice))
        when {
            playerChoice == computerChoice -> {
                //text_Com.setText(getChoiceString(computerChoice))
                text_Result.setText(R.string.draw)
            }

            (playerChoice == Choice.SCISSORS && computerChoice == Choice.PAPER) ||
                    (playerChoice == Choice.ROCK && computerChoice == Choice.SCISSORS) ||
                    (playerChoice == Choice.PAPER && computerChoice == Choice.ROCK) -> {
                //text_Com.setText(getChoiceString(computerChoice))
                text_Result.setText(R.string.win)
            }

            else -> {
                //text_Com.setText(getChoiceString(computerChoice))
                text_Result.setText(R.string.lose)
            }
        }
    }
    fun getChoiceDrawable(choice: Choice): Int {
        return when (choice) {
            Choice.SCISSORS -> R.drawable.scissor
            Choice.ROCK -> R.drawable.rock
            Choice.PAPER -> R.drawable.paper
        }
    }





    }
