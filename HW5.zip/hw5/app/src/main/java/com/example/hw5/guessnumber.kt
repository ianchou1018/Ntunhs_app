package com.example.hw5

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.util.Random

class guessnumber : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_guessnumber)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val textview3=findViewById<TextView>(R.id.textView3)
        val guessbtn=findViewById<Button>(R.id.guess_btn)
        val resetbtn=findViewById<Button>(R.id.reset_btn)
        val guessText=findViewById<EditText>(R.id.guessText)

        var answer:Int
        var secret: Int = Random().nextInt(100) + 1
        var backbtn = findViewById<Button>(R.id.back_btn)

guessbtn.setOnClickListener {
    val guessText = guessText.text.toString()
    val guessNum = guessText.toInt()
    if (guessText.isNotEmpty()) {
        try {
    answer = guessNum - secret
    var ans_str: String = "猜對了！"
    if (answer > 0) {
        ans_str = "猜小一點"
    } else if (answer < 0) {
        ans_str = "猜大一點"
    }
            textview3.text= ans_str
        }catch (e: NumberFormatException) {
            Toast.makeText(this, "請輸入有效的數字", Toast.LENGTH_SHORT).show()
        }
    } else {
        Toast.makeText(this, "請輸入一個數字", Toast.LENGTH_SHORT).show()
    }



    resetbtn.setOnClickListener {
        secret = Random().nextInt(1000) + 1
        textview3.text = "再猜一次"
    }



}

        backbtn.setOnClickListener {
            finish()
        }

    }
}