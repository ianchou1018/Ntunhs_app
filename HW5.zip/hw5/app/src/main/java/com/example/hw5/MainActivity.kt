package com.example.hw5

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val button= findViewById<Button>(R.id.button)
        val button2= findViewById<Button>(R.id.button2)

        button.setOnClickListener{
            var seconIntent= Intent( this, guessnumber::class.java)
            startActivity(seconIntent)

        }

        button2.setOnClickListener{
            var seconIntent2= Intent( this, rockpaperscissor::class.java)
            startActivity(seconIntent2)

        }






    }
}