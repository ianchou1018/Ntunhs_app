package com.example.midtern

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val checkBox1=findViewById<CheckBox>(R.id.checkBox)
        val checkBox2=findViewById<CheckBox>(R.id.checkBox2)
        val btnChangeActivity = findViewById<Button>(R.id.btnChangeActivity)
        val textView13=findViewById<TextView>(R.id.textView13)
        val edtName= findViewById<TextView>(R.id.edtName)
        val spnnumber=findViewById<Spinner>(R.id.spnnumber)
        val spnnumber2=findViewById<Spinner>(R.id.spnnumber2)
        val adapter=ArrayAdapter.createFromResource(this,R.array.number,
        android.R.layout.simple_spinner_dropdown_item
        )
        val adapter2=ArrayAdapter.createFromResource(this,R.array.number2,
            android.R.layout.simple_spinner_dropdown_item
        )
                spnnumber.adapter=adapter
      spnnumber2.adapter=adapter2




        btnChangeActivity.setOnClickListener{

            var bundle=Bundle()
            var name = edtName.text.toString()
            bundle.putString("name", name)
            var needs= textView13.text.toString()
            bundle.putString("needs", needs)
            var number=spnnumber.getSelectedItem()
            bundle.putString("number", number.toString())
            var number2=spnnumber2.getSelectedItem()
            bundle.putString("number2", number2.toString())

            if(checkBox1.isChecked()==true && checkBox2.isChecked()==true){
                textView13.setText("需要兒童椅、兒童餐具")
            }else if(checkBox1.isChecked()==true && checkBox2.isChecked()==false){
                textView13.setText("需要兒童椅")
            }else if(checkBox1.isChecked()==false && checkBox2.isChecked()==true){
                textView13.setText("需要兒童餐具")
            }else {
                textView13.setText("")
            }

            var seconIntent= Intent( this, SecondActivity::class.java)
            seconIntent.putExtra("key", bundle)
            startActivity(seconIntent)







            //  var cheir=checkBox1.isChecked
           // bundle.putString("needscheir",  cheir.toString())
          //  var fork=checkBox2.isChecked
          //  bundle.putString("needsfork", fork.toString())

           // val cheirText=if (cheir){"需要兒童椅"}else{"不需要兒童椅"}
           // val forkText=if (fork){"需要兒童餐具"}else{"不需要兒童餐具"}
        }

    }
}