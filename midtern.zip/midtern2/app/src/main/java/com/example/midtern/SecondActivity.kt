package com.example.midtern

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class SecondActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)


        val txttest=findViewById<TextView>(R.id.txttest)
        val btnBacktoFirst = findViewById<Button>(R.id.btnBacktoFirst)
        val text=intent.getBundleExtra("key")?.getString("name").toString()
        val text2=intent.getBundleExtra("key")?.getString("number").toString()
        val text3=intent.getBundleExtra("key")?.getString("number2").toString()
        val text4=intent.getBundleExtra("key")?.getString("needs").toString()
        val textView12=findViewById<TextView>(R.id.textView12)
        textView12.setText(text4)



        val textView6=findViewById<TextView>(R.id.textView6)
        textView6.setText(text2)

        val textView7=findViewById<TextView>(R.id.textView7)
        textView7.setText(text3)

        txttest.setText(text)

        btnBacktoFirst.setOnClickListener{
            finish()
        }
    }





    var lastTime: Long = 0
    override fun finish() {
        val currentTime = System.currentTimeMillis()
        if (currentTime- lastTime > 3 * 1000) {
            lastTime = currentTime
            Toast.makeText(this,  "再按一下離開", Toast.LENGTH_SHORT).show()
        } else {
        }
        super.finish()
    }





    }
